/**
 * A Quit class.
 *
 * @author Shurgil and barisya
 */
public class Quit implements Task<Void> {
/**
 * constructor.
 */
    public Quit() {
    }
/**
 * run.
 * @return void.
 */
    public Void run() {
        System.exit(0);
        return null;
    }
/**
 * implements task.
 */
    public void newstop() {

    }
}
