
    public class Factorial {
        /**
         * This is a program that calculates the factorial of a number.
         * It could calculate it in a recursive way and in an iterative way
         * and will print the answer for both ways.
         *
         * @param args command line arguments.
         */
        public static void main(String[] args) {
            //converting the command line arguments to a long
            long num = Long.parseLong(args[0]);
            //printing the answer (the return value) from the recursive function
            System.out.println("recursive: " + factorialRecursive(num));
            //printing the answer (the return value) from the iterative function
            System.out.println("iterative: " + factorialIter(num));
        }
        /**
         * This function calculates the factorial
         * of a number in the iterative way.
         *
         * @param num the number for which we want to calculate its factorial.
         * @return ans the answer of the calculations.
         */
        public static long factorialIter(long num) {
            long ans = 1;
            //calculating in a for loop
            for (long i = 1; i < num + 1; i++) {
                ans = (i * ans);
            }
            return ans;
        }
        /**
         * This function calculates the factorial
         * of a number in the recursive way.
         *
         * @param num the number for which we want to calculate its factorial.
         * @return calling the function again recursively, hence it will
         * return the answer of the calculations.
         */
        public static long factorialRecursive(long num) {
            //if the number is negative
            if (num < 0) {
                return -1; //error
            }
            //if the number is 0
            if (num == 0) {
                return 1;
            }
            //calls the function recursively with a number smaller by one
            return (num * factorialRecursive(num - 1));
        }
    }