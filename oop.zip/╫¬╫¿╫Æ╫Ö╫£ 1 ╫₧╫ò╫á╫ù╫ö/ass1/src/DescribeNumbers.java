
public class DescribeNumbers {
    /**
     * This is a program that finds and prints the smallest
     * and biggest number from a list, and the list's average.
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        //allocating memory for a new int array
        int[] numbers = new int[args.length];
        //sending the command line arguments to a function
        //that will convert them to integers
        numbers = stringsToInts(args);
        //printing out the minimum, maximum and average of the list
        System.out.println("min: " + min(numbers));
        System.out.println("max: " + max(numbers));
        System.out.println("avg: " + avg(numbers));
    }
    /**
     * This function converts the command line arguments,
     * that are strings, to integers.
     *
     * @param args command line arguments.
     * @return numbers- the list now as integers.
     */
    public static int[] stringsToInts(String[] args) {
        //allocating memory for a new int array
        int[] numbers = new int[args.length];
        //converts the strings to integers
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = Integer.parseInt(args[i]);
        }
        //and returns the integer array.
        return numbers;
    }
    /**
     * This function finds the smallest number from the list.
     *
     * @param numbers an integer array- the list.
     * @return min after comparing it to the whole list.
     */
    public static int min(int[] numbers) {
        //assign min as the first number of the list
        int min = numbers[0];
        //going over the whole list
        for (int i = 0; i < numbers.length - 1; i++) {
            //if theres a number thats smaller than min
            if (numbers[i + 1] < min) {
                //assign that number to min
                min = numbers[i + 1];
            }
        }
        return min;
    }
    /**
     * This function finds the biggest number from the list.
     *
     * @param numbers an integer array- the list.
     * @return max after comparing it to the whole list.
     */
    public static int max(int[] numbers) {
        //assign min as the first number of the list
        int max = numbers[0];
        //going over the whole list
        for (int i = 0; i < numbers.length - 1; i++) {
            //if theres a number thats bigger than max
            if (numbers[i + 1] > max) {
                //assign that number to max
                max = numbers[i + 1];
            }
        }
        return max;
    }
    /**
     * This function finds the average of the list.
     *
     * @param numbers an integer array- the list.
     * @return avg the average.
     */
    public static float avg(int[] numbers) {
        float sum = 0.0f;
        float avg = 0.0f;
        //summing up the numbers of the list
        for (int i = 0; i < numbers.length; i++) {
            sum += numbers[i];
        }
        //calculating the average
        avg = (sum / (numbers.length));
        return avg;
    }
}