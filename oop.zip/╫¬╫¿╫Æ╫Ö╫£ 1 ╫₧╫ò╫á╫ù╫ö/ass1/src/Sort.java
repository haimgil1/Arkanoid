
public class Sort {
    /**
     * This is a program that finds and prints the smallest
     * and biggest number from a list, and the list's average.
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        //allocating memory for a new int array one
        //size smaller than the original string array
        int[] numbers = new int[args.length - 1];
        //assigning the first member of the list to order
        //it will be either 'asc' or 'desc'
        String order = args[0];
        //putting the strings we converted to integers
        //in the function, into the new integer array
        numbers = stringsToInts(args, numbers);
        //if order equals to 'asc'
        if (order.equals("asc")) {
            //send the list to the sort function by ascending order
            sortAsc(numbers);
            //send the list to the printing function
            printList(numbers);
        //or if order equals to 'desc'
        } else if (order.equals("desc")) {
            //send the list to the sort function by descending order
            sortDesc(numbers);
            //send the list to the printing function
            printList(numbers);
        }
    }
    /**
     * This function converts the command line arguments,
     * that are strings, to integers.
     *
     * @param args command line arguments.
     * @param numbers an integer array to put the integers in.
     * @return numbers- the list now as integers.
     */
    public static int[] stringsToInts(String[] args, int[] numbers) {
        //converts the strings to integers
        for (int i = 1; i < args.length; i++) {
            numbers[i - 1] = Integer.parseInt(args[i]);
        }
        //and returns the integer array.
        return numbers;
    }
    /**
     * This function sorts the list by ascending order.
     *
     * @param numbers an integer array- the list.
     */
    public static void sortAsc(int[] numbers) {
        //going over the whole list
        for (int i = 0; i < numbers.length - 1; i++) {
            //for each element in the list
            for (int j = 0; j < numbers.length - 1 - i; j++) {
                //if a number is bigger than a number
                //that's next on the list, swap them
                if (numbers[j] > numbers[j + 1]) {
                    swap(numbers, j, j + 1);
                }
            }
        }
    }
    /**
     * This function sorts the list by descending order.
     *
     * @param numbers an integer array- the list.
     */
    public static void sortDesc(int[] numbers) {
        //going over the whole list
        for (int i = 0; i < numbers.length - 1; i++) {
            //for each element in the list
            for (int j = 0; j < numbers.length - 1 - i; j++) {
                //if a number is smaller than a number
                //that's next on the list, swap them
                if (numbers[j] < numbers[j + 1]) {
                    swap(numbers, j, j + 1);
                }
            }
        }
    }
    /**
     * This function swaps between two numbers in the list.
     *
     * @param numbers an integer array- the list.
     * @param j a number on the list
     * @param i the next number on the list
     */
    public static void swap(int[] numbers, int j, int i) {
        int temp = 0;
        //puts the first number in temp so as to not lose the number
        temp = numbers[j];
        //swaps them
        numbers[j] = numbers[i];
        numbers[i] = temp;
    }
    /**
     * This function prints the list.
     *
     * @param numbers an integer array- the list.
     */
    public static void printList(int[] numbers) {
        //goes over the whole list
        for (int i = 0; i < numbers.length; i++) {
            //prints it out in a line
            System.out.print(numbers[i] + " ");
        }
        System.out.println();
    }
}