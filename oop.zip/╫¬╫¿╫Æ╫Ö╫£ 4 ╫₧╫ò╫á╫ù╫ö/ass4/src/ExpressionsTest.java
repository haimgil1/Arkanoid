import java.util.Map;
import java.util.TreeMap;

/**
 * A Var class. implements Expression
 *
 * @author Shurgil and barisya
 */
public class ExpressionsTest {

    /**
     * This function makes a few expressions, evaluates, differintiate and
     * simplifies them.
     *
     * @param args
     *            command line arguments.
     * @throws Exception
     *             if there are no variables in the the expression of if there'a a
     *             variable that doesn't appear in the map
     */
    public static void main(final String[] args) throws Exception {
        Expression e1 = new Plus(new Mult(2, "x"), new Plus(new Sin(new Mult(4,
                "y")), new Pow("e", "x")));
        System.out.println(e1);
        Map<String, Double> assignment = new TreeMap<String, Double>();
        assignment.put("x", 2.0);
        assignment.put("y", 0.25);
        assignment.put("e", 2.71);
        double value = e1.evaluate(assignment);
        System.out.println(value);
        Expression e2 = e1.differentiate("x");
        System.out.println(e2);
        double value2 = e2.evaluate(assignment);
        System.out.println(value2);
        System.out.println(e2.simplify());
    }
}
