import java.util.Map;

/**
 * A Sin class. extends UnaryExpression
 *
 * @author Shurgil and barisya
 */
public class Sin extends UnaryExpression {

    /**
     * constructor.
     *
     * @param argument
     *            the expression for this operator as an expression.
     */
    public Sin(Expression argument) {
        super(argument);
    }

    /**
     * constructor.
     *
     * @param varName
     *            the expression for this operator as a variable name.
     */
    public Sin(String varName) {
        super(varName);
    }

    /**
     * constructor.
     *
     * @param num
     *            the expression for this operator as a number.
     */
    public Sin(int num) {
        super(num);
    }

    /**
     * @return the value of the expression
     */
    public double getValue() {
        return Math.sin(Math.toRadians(super.getArgument().getValue()));
    }

    /**
     * @return the expression in a string format
     */
    public String toString() {
        return "sin(" + super.getArgument().toString() + ")";
    }

    /**
     * assigns an expression to the variable in the expression.
     * @param var
     *            - the name of the variable in the current expression.
     * @param expression
     *            - the given expression we need to assign to the variable
     * @return this - return the new expression.
     */
    public Expression assign(String var, Expression expression) {
        if (super.getArgument().toString() == var) {
            return new Sin(expression);
        }
        return this;
    }

    /**
     * evaluates the expression using the variable values provided in the map.
     * @param m
     *            - the map the has the values of each variable.
     * @throws Exception
     *             if there are no variables in the the expression or if theres
     *             a variable that doesn't appear in the map
     * @return returns the result.
     */
    public double evaluate(Map<String, Double> m) throws Exception {
        for (int i = 0; i < super.getVariables().size(); i++) {
            if (!m.containsKey(super.getVariables().get(i).toString())) {
                throw new Exception(
                        "There are variables that don't appear in the map");
            }
        }
        if (super.getArgument().getVariables().isEmpty()) {
            return this.evaluate();
        }
        if (m.containsKey(super.getArgument().toString())) {
            return Math.sin(Math.toRadians(m
                    .get(super.getArgument().toString())));
        }
        return Math.sin(Math.toRadians(super.getArgument().evaluate(m)));
    }

    /**
     * evaluates the expression.
     * @throws Exception
     *             if there are no variables in the the expression
     * @return argument - returns the result.
     */
    public double evaluate() throws Exception {
        return Math.sin(Math.toRadians(super.getArgument().evaluate()));
    }

    /**
     * Returns the expression tree resulting from differentiating the current
     * expression relative to variable `var`.
     * @param var
     *            - the name of the variable we're doing the differentiating on
     * @return the new expression.
     */
    public Expression differentiate(String var) {
        if (super.getArgument().getVariables().isEmpty()) {
            return new Num(0);
        }
        return new Mult(new Cos(super.getArgument()), super.getArgument()
                .differentiate(var));
    }

    /**
     * @throws Exception
     *             if there are no variables in the the expression
     * @return a simplified version of the current expression.
     */
    public Expression simplify() throws Exception {
        if (super.getArgument().getVariables().isEmpty()) {
            return new Num(this.evaluate());
        }
        return this;
    }

}
