import java.util.List;
import java.util.Map;

/**
 * A Collidable interface.
 *
 * @author Shurgil and barisya
 */
public interface Expression {

    /**
     * evaluates the expression using the variable values provided in the map.
     * 
     * @param assignment
     *            - the map the has the values of each variable.
     * @throws Exception
     *             if there are no variables in the the expression or if theres
     *             a variable that doesn't appear in the map
     * @return returns the result.
     */
    double evaluate(Map<String, Double> assignment) throws Exception;

    /**
     * evaluates the expression.
     * 
     * @throws Exception
     *             if there are no variables in the the expression
     * @return the result.
     */
    double evaluate() throws Exception;

    /**
     * @return a list of all the variables in the expression
     */
    List<String> getVariables();

    /**
     * @return the expression in a string format
     */
    String toString();

    /**
     * assigns an expression to the variable in the expression.
     * 
     * @param var
     *            - the name of the variable in the current expression.
     * @param expression
     *            - the given expression we need to assign to the variable
     * @return the new expression.
     */
    Expression assign(String var, Expression expression);

    /**
     * @return the value of the expression
     */
    double getValue();

    /**
     * Returns the expression tree resulting from differentiating the current
     * expression relative to variable `var`.
     * 
     * @param var
     *            - the name of the variable we're doing the differentiating on
     * @return the new expression.
     */
    Expression differentiate(String var);

    /**
     * @throws Exception
     *             if there are no variables in the the expression
     * @return a simplified version of the current expression.
     */
    Expression simplify() throws Exception;
}