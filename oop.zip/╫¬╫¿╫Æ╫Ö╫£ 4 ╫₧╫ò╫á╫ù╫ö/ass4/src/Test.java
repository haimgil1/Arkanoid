import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Test {
    public static void main(final String[] args) {
        Expression e2 = new Mult(new Plus(new Var("x"), new Var("y")), new Num(2));
        Expression e4 = new Plus("x", 2); //shortcut constructor
        UnaryExpression e = new Sin(
                new Pow(
                   new Mult(
                      new Plus(
                         new Mult(new Num(2), new Var("x")),
                         new Var("y")),
                      new Num(4)),
                new Var("x")));
        Num num1 = new Num(3);
        //Expression e2 = new Mult((Expression)num1,(Expression)new Num(2));
        String s = e2.toString();
        System.out.println(s);
        
        
        //get variables
        List<String> vars = e2.getVariables();
        for (String v : vars) {
          System.out.println(v);
        } 
        
        //assign
        Expression e3 = e2.assign("y", e2);
        System.out.println(e3);
        // (x + ((x + y)^2))^2
        e3 = e3.assign("x", new Num(1));
        System.out.println(e3);
        // (1 + ((1 + y)^2))^2
        
        
        //evaluate
        //Map<String, Double> assignment = new TreeMap<String, Double>();
        //assignment.put("x", (double)2);
        //assignment.put("y", (double)4);
        //double value = e2.evaluate(assignment);
        //System.out.println("The result is: " + value);
        
    }
}
