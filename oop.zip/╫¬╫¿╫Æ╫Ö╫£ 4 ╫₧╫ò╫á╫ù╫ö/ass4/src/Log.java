import java.util.Map;

/**
 * A Div class. extends BinaryExpression
 *
 * @author Shurgil and barisya
 */
public class Log extends BinaryExpression {

    /**
     * Constructor.
     *
     * @param base
     *            - the base of the log.
     * @param argument
     *            - the expression of this argument.
     */
    public Log(Expression base, Expression argument) {
        super(base, argument);
    }

    /**
     * Constructor.
     *
     * @param base
     *            - the base of the log.
     * @param argument
     *            - the expression of this argument.
     */
    public Log(Expression base, int argument) {
        super(base, argument);
    }

    /**
     * Constructor.
     *
     * @param base
     *            - the base of the log.
     * @param argument
     *            - the expression of this argument.
     */
    public Log(int base, Expression argument) {
        super(base, argument);
    }

    /**
     * Constructor.
     *
     * @param base
     *            - the base of the log.
     * @param argument
     *            - the expression of this argument.
     */
    public Log(int base, int argument) {
        super(base, argument);
    }

    /**
     * Constructor.
     *
     * @param base
     *            - the base of the log.
     * @param argument
     *            - the expression of this argument.
     */
    public Log(Expression base, String argument) {
        super(base, argument);
    }

    /**
     * Constructor.
     *
     * @param base
     *            - the base of the log.
     * @param argument
     *            - the expression of this argument.
     */
    public Log(String base, Expression argument) {
        super(base, argument);
    }

    /**
     * Constructor.
     *
     * @param base
     *            - the base of the log.
     * @param argument
     *            - the expression of this argument.
     */
    public Log(String base, String argument) {
        super(base, argument);
    }

    /**
     * Constructor.
     *
     * @param base
     *            - the base of the log.
     * @param argument
     *            - the expression of this argument.
     */
    public Log(int base, String argument) {
        super(base, argument);
    }

    /**
     * Constructor.
     *
     * @param base
     *            - the base of the log.
     * @param argument
     *            - the expression of this argument.
     */
    public Log(String base, int argument) {
        super(base, argument);
    }

    /**
     * @return the value of the expression
     */
    public double getValue() {
        return Math.log10(super.getLeftArgument().getValue())
                / Math.log10(super.getRightArgument().getValue());
    }

    @Override
    /**
     * @return the expression in a string format
     */
    public String toString() {
        return "log(" + super.getRightArgument().toString() + ","
                + super.getLeftArgument().toString() + ")";
    }

    /**
     * assigns an expression to the variable in the expression.
     * 
     * @param var
     *            - the name of the variable in the current expression.
     * @param expression
     *            - the given expression we need to assign to the variable
     * @return the new expression.
     */
    public Expression assign(String var, Expression expression) {
        System.out.println("assin log");
        if (super.getRightArgument().toString().equals(var)) {
            if (super.getLeftArgument().toString().equals(var)) {
                return new Log(expression, expression);
            }
            return new Log(expression, super.getLeftArgument());
        }
        if (super.getLeftArgument().toString().equals(var)) {
            return new Log(super.getRightArgument(), expression);
        }
        return new Log(super.getRightArgument().assign(var, expression), super
                .getLeftArgument().assign(var, expression));
    }

    /**
     * evaluates the expression using the variable values provided in the map.
     * 
     * @param m
     *            - the map the has the values of each variable.
     * @throws Exception
     *             if there are no variables in the the expression or if theres
     *             a variable that doesn't appear in the map
     * @return returns the result.
     */
    public double evaluate(Map<String, Double> m) throws Exception {
        for (int i = 0; i < super.getVariables().size(); i++) {
            if (!m.containsKey(super.getVariables().get(i).toString())) {
                throw new Exception(
                        "There are variables that don't appear in the map");
            }
        }
        if (super.getRightArgument().getVariables().isEmpty()
                && super.getLeftArgument().getVariables().isEmpty()) {
            return this.evaluate();
        }
        if (m.containsKey(super.getRightArgument().toString())) {
            if (m.containsKey(super.getLeftArgument().toString())) {
                return Math.log(m.get(super.getLeftArgument().toString()))
                        / Math.log(m.get(super.getRightArgument().toString()));
            }
            return Math.log(super.getLeftArgument().evaluate())
                    / Math.log(m.get(super.getRightArgument().toString()));
        }
        if (m.containsKey(super.getLeftArgument().toString())) {
            return Math.log(m.get(super.getLeftArgument().toString()))
                    / Math.log(super.getLeftArgument().evaluate());
        }
        return Math.log(super.getRightArgument().evaluate(m))
                / Math.log(super.getLeftArgument().evaluate(m));
    }

    /**
     * evaluates the expression.
     * 
     * @throws Exception
     *             if there are no variables in the the expression
     * @return the result.
     */
    public double evaluate() throws Exception {
        return Math.log(super.getRightArgument().evaluate())
                / Math.log(super.getLeftArgument().evaluate());
    }

    /**
     * Returns the expression tree resulting from differentiating the current
     * expression relative to variable `var`.
     * 
     * @param var
     *            - the name of the variable we're doing the differentiating on
     * @return the new expression.
     */
    public Expression differentiate(String var) {
        if (super.getLeftArgument().toString() == var) {
            Expression f = super.getLeftArgument();
            Expression ft = super.getLeftArgument().differentiate(var);
            Expression a = new Div(ft, f);
            return a;
        }
        return this;
    }

    /**
     * @throws Exception
     *             if there are no variables in the the expression
     * @return a simplified version of the current expression.
     */
    public Expression simplify() throws Exception {
        if (super.getLeftArgument().toString()
                .equals(super.getLeftArgument().toString())) {
            return new Num(1);
        }
        if (super.getLeftArgument().getVariables().isEmpty()
                && super.getRightArgument().getVariables().isEmpty()) {
            return new Num(this.evaluate());
        }
        return new Log(super.getRightArgument().simplify(), super
                .getLeftArgument().simplify());
    }
}
