import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * A BaseExpression abstract class. implements the Expression interface
 *
 * @author Shurgil and barisya
 */
public abstract class BaseExpression implements Expression {

    private Expression argument;

    // name of the variable
    private String name;

    // variable value
    private double value;

    /**
     * an abstract method.
     */
    @Override
    public abstract double getValue();

    /**
     * an abstract method.
     */
    @Override
    public abstract String toString();

    /**
     * assigns an expression to the variable in the expression.
     * 
     * @param var
     *            - the name of the variable in the current expression.
     * @param expression
     *            - the given expression we need to assign to the varaible
     * @return argument - return the new expression.
     */
    public Expression assign(String var, Expression expression) {
        List<String> vars = argument.getVariables();
        String s = expression.toString();

        for (int i = 0; i < vars.size(); i++) {
            var = s;
        }
        return argument;
    }

    /**
     * evaluates the expression using the variable values provided in the map.
     * 
     * @param assignment
     *            - the map the has the values of each variable.
     * @return argument - returns the result.
     * @throws Exception
     *             if there are no variables in the the expression or if theres
     *             a variable that doesnt appear in the map
     */
    public double evaluate(Map<String, Double> assignment) throws Exception {
        assignment = new TreeMap<String, Double>();
        if (argument.getVariables() == null) {
            throw new Exception("No variables in the expression");
        } else if (assignment.get(argument.getVariables()) == null) {
            throw new Exception("There is a variable in the"
                    + "expression that doesn't appear in the map");
        }
        return argument.evaluate(assignment);
    }

    /**
     * evaluates the expression.
     * 
     * @return argument - returns the result.
     * @throws Exception
     *             if there are no variables in the the expression
     */
    public double evaluate() throws Exception {
        if (argument.getVariables() == null) {
            throw new Exception("No variables in the expression");
        }
        return argument.evaluate();
    }
}
