import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * A BaseExpression abstract class. implements the Expression interface and
 * extends BaseExpression
 *
 * @author Shurgil and barisya
 */
public abstract class BinaryExpression extends BaseExpression implements
        Expression {

    private Expression leftArgument;
    private Expression rightArgument;

    /**
     * constructs a BinaryExpression given two expressions.
     *
     * @param ex1
     *            - the left expression
     * @param ex2
     *            - the right expression
     */
    public BinaryExpression(Expression ex1, Expression ex2) {
        this.leftArgument = ex1;
        this.rightArgument = ex2;
    }

    /**
     * constructs a BinaryExpression given a string and a number.
     *
     * @param varName
     *            - the name of the variable as the left argument
     * @param num
     *            - a number as the right argument
     */
    public BinaryExpression(String varName, double num) {
        Var variable = new Var(varName);
        Num number = new Num(num);

        this.leftArgument = variable;
        this.rightArgument = number;

    }

    /**
     * constructs a BinaryExpression given a number and a string.
     *
     * @param num
     *            - a number as the left argument
     * @param varName
     *            - the name of the variable as the right argument
     */
    public BinaryExpression(double num, String varName) {
        Var variable = new Var(varName);
        Num number = new Num(num);

        this.leftArgument = number;
        this.rightArgument = variable;
    }

    /**
     * constructs a BinaryExpression given two strings.
     *
     * @param varName1
     *            - the name of a variable as the left argument
     * @param varName2
     *            - the name of a variable as the right argument
     */
    public BinaryExpression(String varName1, String varName2) {
        Var variable1 = new Var(varName1);
        Var variable2 = new Var(varName1);

        this.leftArgument = variable1;
        this.rightArgument = variable2;
    }

    /**
     * constructs a BinaryExpression given two numbers.
     *
     * @param num1
     *            - a number as the left argument
     * @param num2
     *            - a number as the right argument
     */
    public BinaryExpression(double num1, double num2) {
        Num number1 = new Num(num1);
        Num number2 = new Num(num2);

        this.leftArgument = number1;
        this.rightArgument = number2;
    }

    /**
     * constructs a BinaryExpression given an expression and a string.
     *
     * @param leftArgument
     *            - an expression as the left argument
     * @param varName
     *            - the name of a variable as the right argument
     */
    public BinaryExpression(Expression leftArgument, String varName) {
        Var variable = new Var(varName);

        this.leftArgument = leftArgument;
        this.rightArgument = variable;
    }

    /**
     * constructs a BinaryExpression given a string and an expression.
     *
     * @param varName
     *            - the name of a variable as the left argument
     * @param rightArgument
     *            - an expression as the right argument
     */
    public BinaryExpression(String varName, Expression rightArgument) {
        Var variable = new Var(varName);

        this.leftArgument = variable;
        this.rightArgument = rightArgument;
    }

    /**
     * constructs a BinaryExpression given an expression and a number.
     *
     * @param leftArgument
     *            - an expression as the left argument
     * @param num
     *            - a number as the right argument
     */
    public BinaryExpression(Expression leftArgument, double num) {
        Num number = new Num(num);

        this.leftArgument = leftArgument;
        this.rightArgument = number;
    }

    /**
     * constructs a BinaryExpression given a number and an expression.
     *
     * @param num
     *            - a number as the left argument
     * @param rightArgument
     *            - an expression as the right argument
     */
    public BinaryExpression(double num, Expression rightArgument) {
        Num number = new Num(num);

        this.leftArgument = number;
        this.rightArgument = rightArgument;
    }

    /**
     * @return the left argument of the expression
     */
    public Expression getLeftArgument() {
        return this.leftArgument;
    }

    /**
     * @return the right argument of the expression
     */
    public Expression getRightArgument() {
        return this.rightArgument;
    }

    /**
     * @return both a list of all the variables in the expression
     */
    public List<String> getVariables() {
        List<String> both = new ArrayList<String>();
        both.addAll(this.leftArgument.getVariables());
        both.addAll(this.rightArgument.getVariables());
        return both;
    }

    /**
     * evaluates the expression using the variable values provided in the map.
     * 
     * @param assignment
     *            - the map the has the values of each variable.
     * @throws Exception
     *             if there are no variables in the the expression or if theres
     *             a variable that doesnt appear in the map
     * @return value - returns the result.
     */
    public double evaluate(Map<String, Double> assignment) throws Exception {
        if (leftArgument.getVariables() == null) {
            throw new Exception("No variables in the expression");
        } else if (assignment.get(leftArgument.getVariables()) == null) {
            throw new Exception("There is a variable in the"
                    + "expression that doesn't appear in the map");
        }
        double value = leftArgument.evaluate(assignment);
        System.out.println("The result is: " + value);
        return value;
    }

    /**
     * evaluates the expression.
     * 
     * @throws Exception
     *             if there are no variables in the the expression
     * @return value - returns the result.
     */
    public double evaluate() throws Exception {
        if (leftArgument.getVariables() == null) {
            throw new Exception("No variables in the expression");
        }
        double value = leftArgument.evaluate();
        System.out.println("The result is: " + value);
        return value;
    }

    /**
     * an abstract method that will return the differentiated expression.
     * 
     * @param var
     *            - the name of the variable we're doing the differentiating on
     * @return the new expression
     */
    public abstract Expression differentiate(String var);
}