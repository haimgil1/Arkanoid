import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


public class yyyyyy {

	public static void main(final String[] args) throws Exception {




		// ((((e^x) * ((e^x)^2.0)) / ((e^x)^3.0)) * ((((e^x)^4.0) * ((e^x)^3.0)) / ((e^x)^7.0)))
        // ans : 1
        
		Expression e = new Mult(new Div(new Mult(new Pow(new Var("e"), new Var("x")) ,new Pow(new Pow(new Var("e"), new Var("x")) , new Num(2))) , new Pow(new Pow(new Var("e"), new Var("x")) , new Num(3)))
        , new Div( new Mult(new Pow(new Pow(new Var("e"), new Var("x")) , new Num(4)) , new Pow(new Pow(new Var("e"), new Var("x")) , new Num(3)) ) ,e = new Pow(new Pow(new Var("e"), new Var("x")) , new Num(7)) ));
		
		System.out.println(e);
		
        e = e.assign("e", new Num(2.71));
        e = e.assign("x", new Num(0));
        
        System.out.println(e);
        
        double value = e.evaluate();
        
        if (value == 1)
        {
            System.out.println("good =)");
        }else{
            System.out.println("bad =(");
        }
	}
}
