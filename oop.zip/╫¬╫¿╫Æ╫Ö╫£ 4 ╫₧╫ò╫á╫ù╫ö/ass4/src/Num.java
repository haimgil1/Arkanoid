import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * A Num class. implements Expression
 *
 * @author Shurgil and barisya
 */
public class Num implements Expression {
    private double value;

    /**
     * Constructor.
     *
     * @param num
     *            the number's value.
     */
    public Num(double num) {
        this.value = num;
    }

    /**
     * @return the value of the expression
     */
    @Override
    public double getValue() {
        return this.value;
    }

    /**
     * @return the expression in a string format
     */
    @Override
    public String toString() {
        return String.valueOf(this.value);
    }

    /**
     * @return varList a list of all the variables in the expression
     */
    @Override
    public List<String> getVariables() {
        List<String> varList = new ArrayList<String>();
        return varList;
    }

    /**
     * assigns an expression to the variable in the expression.
     * 
     * @param var
     *            - the name of the variable in the current expression.
     * @param expression
     *            - the given expression we need to assign to the variable
     * @return this - return the new expression.
     */
    public Expression assign(String var, Expression expression) {
        return this;
    }

    /**
     * evaluates the expression using the variable values provided in the map.
     * 
     * @param m
     *            - the map the has the values of each variable.
     * @return returns the result.
     */
    public double evaluate(Map<String, Double> m) {
        return this.value;
    }

    /**
     * evaluates the expression.
     * 
     * @return argument - returns the result.
     */
    public double evaluate() {
        return this.value;
    }

    /**
     * Returns the expression tree resulting from differentiating the current
     * expression relative to variable `var`.
     * 
     * @param var
     *            - the name of the variable we're doing the differentiating on
     * @return the new expression.
     */
    public Expression differentiate(String var) {
        return new Num(0);
    }

    /**
     * @throws Exception
     *             if there are no variables in the the expression
     * @return a simplified version of the current expression.
     */
    public Expression simplify() throws Exception {
        return this;
    }
}
