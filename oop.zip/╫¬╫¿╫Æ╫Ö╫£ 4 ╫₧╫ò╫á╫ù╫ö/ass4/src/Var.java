import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * A Var class. implements Expression
 *
 * @author Shurgil and barisya
 */
public class Var implements Expression {

    private List<String> varList;

    // name of the variable
    private String name = null;

    // variable value
    private double value = 0;

    /**
     * Constructor.
     *
     * @param name
     *            the name of the variable.
     */
    public Var(String name) {
        this.name = name;
        this.value = 0;
        this.varList = new ArrayList<String>();
        varList.add(name);
    }

    /**
     * @return the expression in a string format
     */
    @Override
    public String toString() {
        return this.name;
    }

    /**
     * @return the value of the expression
     */
    public double getValue() {
        return this.value;
    }

    /**
     * @return varList a list of all the variables in the expression
     */
    @Override
    public List<String> getVariables() {
        return this.varList;
    }

    /**
     * assigns an expression to the variable in the expression.
     * @param var
     *            - the name of the variable in the current expression.
     * @param expression
     *            - the given expression we need to assign to the variable
     * @return this - return the new expression.
     */
    public Expression assign(String var, Expression expression) {
        if (this.name.equals(var)) {
            return expression;
        }
        return this;
    }

    /**
     * evaluates the expression using the variable values provided in the map.
     * @param m
     *            - the map the has the values of each variable.
     * @throws Exception
     *             if there are no variables in the the expression or if theres
     *             a variable that doesn't appear in the map
     * @return returns the result.
     */
    public double evaluate(Map<String, Double> m) throws Exception {
        if (!m.containsKey(this.name)) {
            throw new Exception("No variables in the expression");
        }
        return m.get(this.name);
    }

    /**
     * evaluates the expression.
     * @throws Exception
     *             if there are no variables in the the expression
     * @return argument - returns the result.
     */
    public double evaluate() throws Exception {
        if (this.name == null) {
            throw new Exception("No variables in the expression");
        } else {
            return this.value;
        }
    }

    /**
     * Returns the expression tree resulting from differentiating the current
     * expression relative to variable `var`.
     * @param var
     *            - the name of the variable we're doing the differentiating on
     * @return the new expression.
     */
    @Override
    public Expression differentiate(String var) {
        if (this.toString() == var) {
            return new Num(1);
        }
        return new Num(0);
    }

    /**
     * @throws Exception
     *             if there are no variables in the the expression
     * @return a simplified version of the current expression.
     */
    public Expression simplify() throws Exception {
        return this;
    }
}
