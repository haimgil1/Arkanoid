import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * An UnaryExpression abstract class. implements the Expression interface
 *
 * @author Shurgil and barisya
 */
public abstract class UnaryExpression implements Expression {

    private Expression argument;

    /**
     * constructor.
     *
     * @param ex
     *            the expression for this operator as an expression.
     */
    public UnaryExpression(Expression ex) {
        this.argument = ex;
    }

    /**
     * constructor.
     *
     * @param varName
     *            the expression for this operator as a variable name.
     */
    public UnaryExpression(String varName) {
        Var variable = new Var(varName);
        this.argument = variable;
    }

    /**
     * constructor.
     *
     * @param num
     *            the expression for this operator as a number.
     */
    public UnaryExpression(double num) {
        Num number = new Num(num);
        this.argument = number;
    }

    /**
     * @return the value of the expression
     */
    public abstract double getValue();

    /**
     * @return the argument of the expression
     */
    public Expression getArgument() {
        return this.argument;
    }

    /**
     * @return the expression in a string format
     */
    public abstract String toString();

    /**
     * @return l a list of all the variables in the expression
     */
    public List<String> getVariables() {
        List<String> l = this.argument.getVariables();
        return l;
    }

    /**
     * assigns an expression to the variable in the expression.
     * @param var
     *            - the name of the variable in the current expression.
     * @param expression
     *            - the given expression we need to assign to the variable
     * @return this - return the new expression.
     */
    public Expression assign(String var, Expression expression) {
        if (this.argument.toString() == var) {
            System.out.println("hello");
            this.argument = expression;
        }
        return this;
    }

    /**
     * evaluates the expression using the variable values provided in the map.
     * @param assignment
     *            - the map the has the values of each variable.
     * @throws Exception
     *             if there are no variables in the the expression or if theres
     *             a variable that doesn't appear in the map
     * @return returns the result.
     */
    public double evaluate(Map<String, Double> assignment) throws Exception {
        assignment = new TreeMap<String, Double>();
        if (argument.getVariables() == null) {
            throw new Exception("No variables in the expression");
        } else if (assignment.get(argument.getVariables()) == null) {
            throw new Exception("There is a variable in the"
                    + "expression that doesn't appear in the map");
        }
        double value = argument.evaluate(assignment);
        return value;
    }

    /**
     * evaluates the expression.
     * @throws Exception
     *             if there are no variables in the the expression
     * @return argument - returns the result.
     */
    public double evaluate() throws Exception {
        if (argument.getVariables() == null) {
            throw new Exception("No variables in the expression");
        }
        double value = argument.evaluate();
        System.out.println("The result is: " + value);
        return value;
    }

    /**
     * Returns the expression tree resulting from differentiating the current
     * expression relative to variable `var`.
     * @param var
     *            - the name of the variable we're doing the differentiating on
     * @return the new expression.
     */
    public abstract Expression differentiate(String var);

    /**
     * @throws Exception
     *             if there are no variables in the the expression
     * @return a simplified version of the current expression.
     */
    public abstract Expression simplify() throws Exception;
}
