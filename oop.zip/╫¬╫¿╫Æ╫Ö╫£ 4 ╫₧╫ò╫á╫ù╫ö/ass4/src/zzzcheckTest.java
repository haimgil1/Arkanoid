import java.util.List;
import java.util.Map;
import java.util.TreeMap;


public class zzzcheckTest {
	 public static void main(final String[] args) throws Exception {
	

         System.out.println("liron1:");
	     Expression liron1 = new Neg(new Var("x"));
         System.out.println(liron1);
         System.out.println(liron1.evaluate());

         Map<String, Double> assignmentLiron = new TreeMap<String, Double>();
         assignmentLiron.put("x", 50.0);
         double valueLiron = liron1.evaluate(assignmentLiron);
         System.out.println("The result is: " + valueLiron);
         System.out.println(liron1.differentiate("x"));
         System.out.println("simplify");
         System.out.println(liron1.simplify());
         
         System.out.println("liron2:");
         Expression liron2 = new Pow(new Var("x"), new Var("y"));
         System.out.println(liron2);
         double a = liron2.evaluate();
         
         
         Map<String, Double> assignmentLiron2 = new TreeMap<String, Double>();
         assignmentLiron2.put("x", 10.0);
         assignmentLiron2.put("y", 2.0);
         double valueLiron2 = liron2.evaluate(assignmentLiron2);
         System.out.println("The result is: " + valueLiron2);
         System.out.println(liron2.differentiate("x"));
         System.out.println("simplify");
         System.out.println(liron2.simplify());
         
         
	     System.out.println("e0:");
		 Expression e001 = new Mult(2, "x");
		 Expression e002 = new Sin(new Mult(4, "y"));
		 Expression e003 = new Pow("e", "x");
		 Expression e004 = new Plus(e001, e002);
		 Expression e005 = new Plus(e004, e003);
		 System.out.println(e005);
		 
		 Map<String, Double> assignment02 = new TreeMap<String, Double>();
		 assignment02.put("x", 2.0);
		 assignment02.put("y", 0.25);
		 assignment02.put("e", 2.71);
		 double value02 = e005.evaluate(assignment02);
		 System.out.println("The result is: " + value02);
		 
		 Expression e006 = e005.differentiate("x");
		 
		 System.out.println("The differentiate is: " + e006);
         System.out.println("simplify");
         System.out.println(e006.simplify());
		 double value03 = e006.evaluate(assignment02);
		 System.out.println("The result2 is: " + value03);
		 
		 Map<String, Double> assignment = new TreeMap<String, Double>();
         assignment.put("x", 50.0);
         double value = e001.evaluate(assignment);
         System.out.println("The result is: " + value);
         

         System.out.println("e4:");
         Expression e4 = new Pow(new Var("x"), new Var("y"));
         System.out.println(e4);
         double a2 = e4.evaluate();
         System.out.println("the result of a: " + a2);
         
         Map<String, Double> assignment2 = new TreeMap<String, Double>();
         assignment2.put("x", 10.0);
         assignment2.put("y", 2.0);
         double value2 = e4.evaluate(assignment2);
         System.out.println("The result is: " + value2);
         Expression diff1 = e4.differentiate("z");
         System.out.println(diff1);
         List<String> l = e4.getVariables();
         for (int i = 0; i < l.size(); i++) {
             System.out.println(l.get(i));
         }
         System.out.println("simplify");
         System.out.println(e4.simplify());
         
         System.out.println("example");
         Expression e = new Pow(new Plus(new Var("x"), new Var("y")), new Num(2));
         System.out.println(e.differentiate("x"));
        // the result is:
        // (((x + y) ^ 2.0) * (((1.0 + 0.0) * (2.0 / (x + y))) + (0.0 * log(e, (x + y)))))
         System.out.println("simplify");
         System.out.println(e.differentiate("x").simplify());
      // the result is:
      // (((x + y) ^ 2.0) * (2.0 / (x + y)))

         System.out.println("e5:");
         Expression e5 = new Plus(new Var("z"), new Num(3));
         Map<String, Double> assignment3 = new TreeMap<String, Double>();
         assignment3.put("z", 2.0);
         double value3 = e5.evaluate(assignment3);
         System.out.println("The result is: " + value3);
         List<String> l1 = e5.getVariables();
         for (int i = 0; i < l1.size(); i++) {
             System.out.println(l1.get(i));
         }
         System.out.println(e5.differentiate("z"));
         System.out.println("simplify");
         System.out.println(e5.simplify());
         

         System.out.println("e6:");
         Expression e6 = new Minus(new Var("x"), new Plus(new Var("y"), new Num(3)));
         System.out.println(e6);
         Expression e7 = e6.assign("y", new Num(5));
         System.out.println(e7);
         System.out.println(e6);
         System.out.println(e7.differentiate("x"));
         System.out.println("simplify");
         System.out.println(e6.simplify());
         
         System.out.println("e8:");
         Expression e8 = new Mult(new Var ("z"), new Num (5));
         System.out.println(e8.differentiate("z"));
         System.out.println("simplify");
         System.out.println(e8.simplify());

         System.out.println("e9:");
         Expression e9 = new Mult(new Num(2), new Plus(new Num (5), new Var ("z")));
         System.out.println(e9);
         System.out.println("simplify");
         System.out.println(e9.simplify()); 
         
		 
		// (2x) + (sin(4y)) + (e^x)
		 
		//Print the value of the expression with (x=2,y=0.25,e=2.71)
		
        /*System.out.println("e23:");
	    Expression e23 = new Pow(new Plus (new Plus(new Var("x"), new Var("y")) ,
	             new Plus(new Var("z"), new Var("w")) ), new Num(4));
	    System.out.println(e23);
        Map<String, Double> assignment31 = new TreeMap<String, Double>();
        //List<String> vars = null;
        List<String> l11 = e23.getVariables();
        for (int i = 0; i < l.size(); i++) {
            System.out.println(l.get(i));
        }
        assignment3.put("x",  2.0);
        assignment3.put("y",  4.0);
        assignment3.put("z",  6.0);
        assignment3.put("w",  10.0);
        double value31 = e23.evaluate(assignment31);
	    System.out.println(value31);*/
		 
	    System.out.println("e10 plus:");
        Expression e10 = new Plus("x", 3);
        System.out.println(e10);
        System.out.println(e10.differentiate("x"));
        System.out.println("simplify");
        System.out.println(e10.simplify());
        
        System.out.println("e11 zeros:");
        Expression e11 = new Plus(new Plus(0, 0), new Plus(0, 3));
        System.out.println(e11);
        //System.out.println(e11.differentiate("x"));
        System.out.println("simplify");
        System.out.println(e11.simplify());

        System.out.println("e12 zeros:");
        Expression e12 = new Plus(new Plus(4, 0), new Mult(0, 5));
        System.out.println(e12);
        //System.out.println(e11.differentiate("x"));
        System.out.println("simplify");
        System.out.println(e12.simplify());
	    
		 /*
		
		 Expression e2 = new Neg(new Var("x"));
		 System.out.println(e2);
		 System.out.println(e2.evaluate());
		 
		 Map<String, Double> assignment = new TreeMap<String, Double>();
		 assignment.put("x", 50.0);
		 double value = e2.evaluate(assignment);
		 System.out.println("The result is: " + value);
		 
		 
		 Expression e4 = new Pow(new Var("x"), new Var("y"));
		 System.out.println(e4);
		 double a = e4.evaluate();
		 
		 Map<String, Double> assignment2 = new TreeMap<String, Double>();
		 assignment2.put("x", 10.0);
		 assignment2.put("y", 2.0);
		 double value2 = e4.evaluate(assignment2);
		 System.out.println("The result is: " + value2);
		 */
		 
		 /*
		 Expression e4 = new Minus(new Var("y"), new Var("x"));
		 System.out.println(e4);
		 Expression e5 = e4.assign("x", new Num(5));
		 System.out.println(e5);
		 System.out.println(e4);
		 
		 List<String> l = e4.getVariables();
		 System.out.println(l.get(0));
		 System.out.println(l.get(1));
		 */

        System.out.println("good:)");
	 }

}
