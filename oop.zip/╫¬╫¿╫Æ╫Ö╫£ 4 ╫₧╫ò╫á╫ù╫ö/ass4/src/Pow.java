import java.util.Map;

/**
 * A Plus class. extends BinaryExpression
 *
 * @author Shurgil and barisya
 */
public class Pow extends BinaryExpression {

    /**
     * Constructor.
     *
     * @param leftArgument
     *            - left argument expression.
     * @param rightArgument
     *            - right argument expression.
     */
    public Pow(Expression leftArgument, Expression rightArgument) {
        super(leftArgument, rightArgument);
    }

    /**
     * Constructor.
     *
     * @param varName
     *            - left argument expression.
     * @param num
     *            - right argument expression.
     */
    public Pow(String varName, double num) {
        super(varName, num);
    }

    /**
     * Constructor.
     *
     * @param num
     *            - left argument expression.
     * @param varName
     *            - right argument expression.
     */
    public Pow(double num, String varName) {
        super(num, varName);
    }

    /**
     * Constructor.
     *
     * @param varName1
     *            - left argument expression.
     * @param varName2
     *            - right argument expression.
     */
    public Pow(String varName1, String varName2) {
        super(varName1, varName2);
    }

    /**
     * Constructor.
     *
     * @param num1
     *            - left argument expression.
     * @param num2
     *            - right argument expression.
     */
    public Pow(double num1, double num2) {
        super(num1, num2);
    }

    /**
     * Constructor.
     *
     * @param leftArgument
     *            - left argument expression.
     * @param varName
     *            - right argument expression.
     */
    public Pow(Expression leftArgument, String varName) {
        super(leftArgument, varName);
    }

    /**
     * Constructor.
     *
     * @param varName
     *            - left argument expression.
     * @param rightArgument
     *            - right argument expression.
     */
    public Pow(String varName, Expression rightArgument) {
        super(varName, rightArgument);
    }

    /**
     * Constructor.
     *
     * @param leftArgument
     *            - left argument expression.
     * @param num
     *            - right argument expression.
     */
    public Pow(Expression leftArgument, double num) {
        super(leftArgument, num);
    }

    /**
     * Constructor.
     *
     * @param num
     *            - left argument expression.
     * @param rightArgument
     *            - right argument expression.
     */
    public Pow(double num, Expression rightArgument) {
        super(num, rightArgument);
    }

    /**
     * @return the value of the expression
     */
    public double getValue() {
        return Math.pow(super.getLeftArgument().getValue(), super
                .getRightArgument().getValue());
    }

    /**
     * @return the expression in a string format
     */
    @Override
    public String toString() {
        return "(" + super.getLeftArgument().toString() + "^"
                + super.getRightArgument().toString() + ")";
    }

    /**
     * assigns an expression to the variable in the expression.
     * @param var
     *            - the name of the variable in the current expression.
     * @param expression
     *            - the given expression we need to assign to the variable
     * @return the new expression.
     */
    public Expression assign(String var, Expression expression) {
        if (super.getLeftArgument().toString().equals(var)) {
            if (super.getRightArgument().toString().equals(var)) {
                return new Pow(expression, expression);
            }
            return new Pow(expression, super.getRightArgument().assign(var,
                    expression));
        }
        if (super.getRightArgument().toString().equals(var)) {
            return new Pow(super.getLeftArgument().assign(var, expression),
                    expression);
        }
        return new Pow(super.getLeftArgument().assign(var, expression), super
                .getRightArgument().assign(var, expression));
    }

    /**
     * evaluates the expression using the variable values provided in the map.
     * @param m
     *            - the map the has the values of each variable.
     * @throws Exception
     *             if there are no variables in the the expression or if theres
     *             a variable that doesn't appear in the map
     * @return returns the result.
     */
    public double evaluate(Map<String, Double> m) throws Exception {
        for (int i = 0; i < super.getVariables().size(); i++) {
            if (!m.containsKey(super.getVariables().get(i).toString())) {
                throw new Exception(
                        "There are variables that don't appear in the map");
            }
        }
        if (m.containsKey(super.getLeftArgument().toString())) {
            if (m.containsKey(super.getRightArgument().toString())) {
                return Math.pow(m.get(super.getLeftArgument().toString()),
                        m.get(super.getRightArgument().toString()));
            }
            return Math.pow(m.get(super.getLeftArgument().toString()), super
                    .getRightArgument().evaluate(m));
        }
        if (m.containsKey(super.getRightArgument().toString())) {
            return Math.pow(super.getLeftArgument().evaluate(m),
                    m.get(super.getRightArgument().toString()));
        }
        if (super.getLeftArgument().getVariables().isEmpty()
                && super.getRightArgument().getVariables().isEmpty()) {
            return this.evaluate();
        }
        return Math.pow(super.getLeftArgument().evaluate(m), super
                .getRightArgument().evaluate(m));
    }

    /**
     * evaluates the expression.
     * @throws Exception
     *             if there are no variables in the the expression
     * @return the result.
     */
    public double evaluate() throws Exception {
        return Math.pow(super.getLeftArgument().evaluate(), super
                .getRightArgument().evaluate());
    }

    /**
     * Returns the expression tree resulting from differentiating the current
     * expression relative to variable `var`.
     * @param var
     *            - the name of the variable we're doing the differentiating on
     * @return the new expression.
     */
    @Override
    public Expression differentiate(String var) {
        Expression f = super.getLeftArgument();
        Expression g = super.getRightArgument();
        Expression a = new Pow(f, new Minus(g, new Num(1)));
        Expression b = new Mult(g, f.differentiate(var));
        Expression c = new Mult(f, new Log(new Num(Math.E), f));
        Expression d = new Mult(c, g.differentiate(var));

        return new Mult(a, new Plus(b, d));
    }

    /**
     * @throws Exception
     *             if there are no variables in the the expression
     * @return a simplified version of the current expression.
     */
    public Expression simplify() throws Exception {
        if (super.getLeftArgument().simplify().toString()
                .equals(new Num(1).toString())) {
            return new Num(1);
        }
        if (super.getRightArgument().simplify().toString()
                .equals(new Num(0).toString())) {
            return new Num(1);
        }
        if (super.getRightArgument().simplify().toString()
                .equals(new Num(1).toString())) {
            return super.getLeftArgument().simplify();
        }
        if (super.getLeftArgument().getVariables().isEmpty()
                && super.getRightArgument().getVariables().isEmpty()) {
            return new Num(this.evaluate());
        }
        return new Pow(super.getLeftArgument().simplify(), super
                .getRightArgument().simplify());
    }
}
