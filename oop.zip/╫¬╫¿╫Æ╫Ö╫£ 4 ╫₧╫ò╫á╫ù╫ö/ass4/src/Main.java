public class Main {

    public static void main(String[] args) throws Exception {

        int p1 = ExpressionsTestPart1.main1();
        int p2 = ExpressionsTestPart2.main2();
        int p3 = ExpressionsTestPart3.main3();
        System.out.println("grades: " + p1 + "," + p2 + "," + p3 + " from 64");
        System.out.println("Final grade: " + (p1 + p2 + p3) + " from 64");

    }
}