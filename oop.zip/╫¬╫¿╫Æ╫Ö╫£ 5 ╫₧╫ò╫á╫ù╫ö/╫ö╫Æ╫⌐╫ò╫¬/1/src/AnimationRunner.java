import biuoop.DrawSurface;
import biuoop.GUI;

/**
 * A Ball class.
 *
 * @author Shurgil and barisya
 */
public class AnimationRunner {
    private GUI gui;
    private int framesPerSecond;
    private biuoop.Sleeper sleeper;

    /**
     * constructor of the class.
     * get the gui and run the game.
     * @param gui2 the gui
     */
    public AnimationRunner(GUI gui2) {
        this.gui = gui2;
        this.framesPerSecond = 60;
        biuoop.Sleeper sleeper2 = new biuoop.Sleeper();
        this.sleeper = sleeper2;
    }

    /**
     * run the game.
     * @param animation the animation.
     */
    public void run(Animation animation) {

        int millisecondsPerFrame = 1000 / framesPerSecond;

        while (!animation.shouldStop()) {
            long startTime = System.currentTimeMillis(); // timing
            DrawSurface d = gui.getDrawSurface();

            animation.doOneFrame(d);

            this.gui.show(d);

            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                this.sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }
}
