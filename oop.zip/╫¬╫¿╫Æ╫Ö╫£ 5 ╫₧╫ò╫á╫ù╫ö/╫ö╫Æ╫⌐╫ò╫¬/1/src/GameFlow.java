import java.util.List;

import biuoop.GUI;
import biuoop.KeyboardSensor;
/**
 * A GameFlow class.
 *
 * @author Shurgil and barisya
 */
public class GameFlow {
    private GUI gui;
    private Counter score;
    private Counter lives;
    private KeyboardSensor keyboardSensor;
    private AnimationRunner animationRunner;

    /**
     * the constructor.
     * @param ar the animation runner
     * @param ks the keyboard.
     * @param gui2 the gui.
     */
    public GameFlow(AnimationRunner ar, KeyboardSensor ks, GUI gui2) {
        this.gui = gui2;
        this.animationRunner = ar;
        this.score = new Counter();
        this.lives = new Counter();
        this.lives.increase(7);
        this.keyboardSensor = ks;

    }

    /**
     * ron the levels.
     * @param levels the list of levels.
     */
    public void runLevels(List<LevelInformation> levels) {
        // ...
        for (LevelInformation levelInfo : levels) {

            GameLevel level = new GameLevel(levelInfo, this.score, this.lives,
                    this.gui, this.keyboardSensor, this.animationRunner);

            level.initialize();

            while (level.getremainingBlocks().getValue() > 0
                    && level.getlives().getValue() > 0) {
                level.playOneTurn();
            }

            if (level.getlives().getValue() == 0) {

                this.animationRunner.run(new EndScreen(this.keyboardSensor,
                        this.gui, this.lives, this.score));
            }

        }
        this.animationRunner.run(new EndScreen(this.keyboardSensor, this.gui,
                this.lives, this.score));
    }
}
