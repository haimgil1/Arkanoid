import java.util.List;

import biuoop.KeyboardSensor;
import biuoop.DrawSurface;
import biuoop.GUI;

/**
 * A GameLevel class.
 *
 * @author Shurgil and barisya
 */
public class GameLevel implements Animation {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;
    private Counter remainingBlocks;
    private Counter ballsCounter;
    private Counter score;
    private Counter lives;
    private AnimationRunner runner;
    private boolean running;
    private biuoop.KeyboardSensor keyboard;
    private LevelInformation levelinfi;

    /**
     * the constructor.
     * @param levelinf the levels info.
     * @param score2 the score.
     * @param lives2 the lives.
     * @param gui2 the gui.
     * @param keyboard2 the keyboard.
     * @param runner2 the animation runner.
     */
    public GameLevel(LevelInformation levelinf, Counter score2, Counter lives2,
            GUI gui2, KeyboardSensor keyboard2, AnimationRunner runner2) {
        this.levelinfi = levelinf;
        this.score = score2;
        this.lives = lives2;
        this.gui = gui2;
        this.runner = runner2;
        this.keyboard = keyboard2;
    }

    /**
     * @param c
     *            - a collidable. add a collidable to the list of game
     *            environment.
     */
    public void addCollidable(Collidable c) {
        if (this.environment == null) {
            this.environment = new GameEnvironment();
        }
        this.environment.addCollidable(c);
    }

    /**
     * @param s
     *            a sprite object. add a sprite to the list of sprites.
     */
    public void addSprite(Sprite s) {
        if (this.sprites == null) {
            this.sprites = new SpriteCollection();
        }
        this.sprites.addSprite(s);
    }

    /**
     * Initialize a new game: create the Blocks and Ball (and Paddle) and add
     * them to the game.
     */
    public void initialize() {

        this.remainingBlocks = new Counter();
        this.ballsCounter = new Counter();

        BlockRemover checkremoveblock = new BlockRemover(this,
                this.remainingBlocks);
        BallRemover checkremoveball = new BallRemover(this, this.ballsCounter);
        ScoreTrackingListener checkscore = new ScoreTrackingListener(this.score);

        this.addSprite(this.levelinfi.getBackground());

        for (int i = 0; i < this.levelinfi.blocks().size(); i++) {

            Block block = this.levelinfi.blocks().get(i);
            block.addHitListener(checkremoveblock);
            block.addHitListener(checkscore);
            this.remainingBlocks.increase(1);
            block.addToGame(this);
            block.setHitPoints(1);

        }

        // borders

        Point p1 = new Point(0, 20);
        Block blockUp = new Block(p1, 800.0, 10.0, java.awt.Color.GRAY);
        blockUp.addToGame(this);
        blockUp.setHitPoints(-1);

        ScoreIndicator scoreIndicator = new ScoreIndicator(this.score);
        scoreIndicator.addToGame(this);

        LivesIndicator liveIndicator = new LivesIndicator(this.lives);
        liveIndicator.addToGame(this);

        NameIndicator nameIndicator = new NameIndicator(
                this.levelinfi.levelName());
        nameIndicator.addToGame(this);

        Point p2 = new Point(790, 0);
        Block blockRight = new Block(p2, 10.0, 600.0, java.awt.Color.GRAY);
        blockRight.addToGame(this);
        blockRight.setHitPoints(-1);

        Point p3 = new Point(0, 0);
        Block blockLeft = new Block(p3, 10.0, 600.0, java.awt.Color.GRAY);
        blockLeft.addToGame(this);
        blockLeft.setHitPoints(-1);

        Point p4 = new Point(0, 590);
        Block blockDown = new Block(p4, 800.0, 10.0, java.awt.Color.GRAY);
        blockDown.addHitListener(checkremoveball);
        blockDown.addToGame(this);
        blockDown.setHitPoints(-1);

    }

    /**
     * Run the game -- start the animation loop.
     */
    public void playOneTurn() {

        Point p11 = this.levelinfi.paddleLocation();
        Paddle paddle = new Paddle(p11, this.levelinfi.paddleWidth(), 20.0,
                gui.getKeyboardSensor(), this.gui, this.levelinfi.paddleSpeed());
        paddle.addToGame(this);

        List<Velocity> velocityList = this.levelinfi.initialBallVelocities();
        List<Ball> ballList = this.levelinfi.locationOfBalls();

        for (int i = 0; i < velocityList.size(); i++) {

            Velocity velocity = velocityList.get(i);
            Ball ball1 = ballList.get(i);
            ball1.setVelocity(velocity);
            ball1.addToGame(this);
            ball1.ballSetEnvironment(this.environment);
            this.ballsCounter.increase(1);
        }

        this.runner.run(new CountdownAnimation(2.0, 3, this.sprites));

        this.running = true;

        this.runner.run(this);

        removeSprite(paddle);
        removeCollidable(paddle);

    }

    /**
     * run the game.
     */
    public void run() {
        while (this.lives.getValue() != 0) {
            this.playOneTurn();
            this.lives.decrease(1);
        }
        System.out.println("The End of the Game");
        this.gui.close();
        return;
    }

    /**
     * remove block.
     * @param c a Collidable.
     */
    public void removeCollidable(Collidable c) {
        this.environment.removeCollidable(c);
    }

    /**
     * remove this sprite.
     * @param s a sprite to reemove.
     */
    public void removeSprite(Sprite s) {
        this.sprites.removeSprite(s);
    }

    @Override
    public boolean shouldStop() {
        return !this.running;
    }

    @Override
    public void doOneFrame(DrawSurface d) {

        this.sprites.drawAllOn(d);

        this.sprites.notifyAllTimePassed();

        if (this.remainingBlocks.getValue() == 0
                || this.ballsCounter.getValue() == 0) {
            System.out.println("End one turn");
            this.running = false;
        }

        if (this.remainingBlocks.getValue() == 0) {
            this.score.increase(100);
        }

        if (this.ballsCounter.getValue() == 0) {
            this.lives.decrease(1);
        }

        if (this.keyboard.isPressed("p")) {
            this.runner.run(new PauseScreen(this.keyboard));
        }

    }

    /**
     * check for remaining blocks.
     * @return a counter of blocks.
     */
    public Counter getremainingBlocks() {
        return this.remainingBlocks;
    }
    /**
     * check for remaining lives.
     * @return a counter of lives.
     */
    public Counter getlives() {
        return this.lives;
    }

    /**
     * check for remaining balls.
     * @return a counter of balls.
     */
    public Counter getballsCounter() {
        return this.ballsCounter;
    }

}
