import java.util.ArrayList;
import java.util.List;
/**
 * A DirectHit class.
 *
 * @author Shurgil and barisya
 */
public class DirectHit implements LevelInformation {

    @Override
    public int numberOfBalls() {
        return 1;
    }

    @Override
    public List<Ball> locationOfBalls() {
        List<Ball> balls = new ArrayList<Ball>();
        Ball b1 = new Ball(400, 400, 5, java.awt.Color.WHITE);
        balls.add(b1);
        return balls;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> newList = new ArrayList<Velocity>();
        Velocity velocity = new Velocity(0.001, -4);
        newList.add(velocity);
        return newList;
    }

    @Override
    public int paddleSpeed() {
        return 10;
    }

    @Override
    public int paddleWidth() {
        return 80;
    }

    @Override
    public Point paddleLocation() {
        return new Point(360.0, 570.0);
    }

    @Override
    public String levelName() {
        String str = "Direct Hit";
        return str;
    }

    @Override
    public Sprite getBackground() {
        Point p4 = new Point(0, 0);
        Block backblock = new Block(p4, 800.0, 600.0, java.awt.Color.black);
        return backblock;
    }

    @Override
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<Block>();
        Point p1 = new Point(385, 100);
        Block block1 = new Block(p1, 30.0, 30.0, java.awt.Color.red);
        blockList.add(block1);
        return blockList;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return 1;
    }

}
