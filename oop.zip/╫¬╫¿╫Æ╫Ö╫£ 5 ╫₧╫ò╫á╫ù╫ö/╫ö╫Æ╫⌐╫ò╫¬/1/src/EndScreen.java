import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.KeyboardSensor;
/**
 * A EndScreen class.
 *
 * @author Shurgil and barisya
 */
public class EndScreen implements Animation {
    private KeyboardSensor keyboard;
    private boolean stop;
    private GUI gui;
    private Counter live;
    private Counter score;

    /**
     * the constructor.
     * @param k the keyboard.
     * @param gui2 the gui.
     * @param live2 the counter of lives
     * @param score2 the counter of score.
     */
    public EndScreen(KeyboardSensor k, GUI gui2, Counter live2, Counter score2) {
        this.gui = gui2;
        this.keyboard = k;
        this.stop = false;
        this.live = live2;
        this.score = score2;
    }

    /**
     * @param d the drawsurface.
     */
    public void doOneFrame(DrawSurface d) {
        if (this.live.getValue() > 0) {
            d.drawText(10, d.getHeight() / 2, "You Win! Your score is "
                    + this.score.getValue(), 32);
        } else {
            d.drawText(10, d.getHeight() / 2, "Game Over. Your score is "
                    + this.score.getValue(), 32);
        }
        if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) {
            this.gui.close();
            return;
        }
    }

    /**
     * @return boolean if should stop.
     */
    public boolean shouldStop() {
        return this.stop;
    }
}
