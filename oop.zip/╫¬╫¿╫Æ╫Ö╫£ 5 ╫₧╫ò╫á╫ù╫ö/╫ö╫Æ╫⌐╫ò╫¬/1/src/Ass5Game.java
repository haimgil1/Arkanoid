import java.util.ArrayList;
import java.util.List;

import biuoop.GUI;
import biuoop.KeyboardSensor;

/**
 * A Ass5GameLevel class. - main.
 *
 * @author Shurgil and barisya
 */
public class Ass5Game {
    /**
     * the main project.
     *
     * @param args
     *            from command line.
     */
    public static void main(String[] args) {

        // allocating memory for a new int array
        int[] numbers = new int[args.length];
        // sending the command line arguments to a function
        // that will convert them to integers
        numbers = stringsToInts(args);

        GUI gui = new GUI("title", 800, 600);
        AnimationRunner animationRunner = new AnimationRunner(gui);
        KeyboardSensor keyboardSensor = gui.getKeyboardSensor();

        LevelInformation level1 = new DirectHit();
        LevelInformation level2 = new WideEasy();
        LevelInformation level3 = new Green3();
        LevelInformation level4 = new FinalFour();
        List<LevelInformation> levels = new ArrayList<LevelInformation>();

        if (numbers.length != 0) {
            for (int i = 0; i < numbers.length; i++) {
                switch (numbers[i]) {
                case 1:
                    levels.add(level1);
                    break;
                case 2:
                    levels.add(level2);
                    break;
                case 3:
                    levels.add(level3);
                    break;
                case 4:
                    levels.add(level4);
                    break;
                default:
                    ;
                    break;
                }
            }
        } else {
            levels.add(level1);
            levels.add(level2);
            levels.add(level3);
            levels.add(level4);
        }

        GameFlow theGame = new GameFlow(animationRunner, keyboardSensor, gui);
        theGame.runLevels(levels);

    }

    /**
     * This function converts the command line arguments, that are strings, to
     * integers.
     *
     * @param args
     *            command line arguments.
     * @return numbers- the list now as integers.
     */
    public static int[] stringsToInts(String[] args) {
        // allocating memory for a new int array
        int[] numbers = new int[args.length];
        // converts the strings to integers
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = Integer.parseInt(args[i]);
        }
        // and returns the integer array.
        return numbers;
    }
}
