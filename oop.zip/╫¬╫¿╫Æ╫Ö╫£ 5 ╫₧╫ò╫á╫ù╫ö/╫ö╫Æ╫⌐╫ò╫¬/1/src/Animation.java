import biuoop.DrawSurface;

/**
 * A Animation class.
 *
 * @author Shurgil and barisya
 */

public interface Animation {
    /**
     * do one frame every time.
     * @param d get the surface.
     */
    void doOneFrame(DrawSurface d);
    /**
     * check every time if the level should stop.
     * @return boolean if should stop.
     */

    boolean shouldStop();
}
