import biuoop.DrawSurface;
/**
 * A BackgroundLevel2 class.
 *
 * @author Shurgil and barisya
 */

public class BackgroundLevel2 implements Sprite {
    /**
     * draw the sprite to the screen.
     * @param d - the draw surface.
     */
    public void drawOn(DrawSurface d) {

        d.setColor(java.awt.Color.white);
        d.fillRectangle(0, 40, 800, 560);

        java.awt.Color yellow3 = new java.awt.Color(243, 233, 163);
        d.setColor(yellow3);
        d.fillCircle(130, 130, 56);
        java.awt.Color yellow2 = new java.awt.Color(240, 216, 56);
        d.setColor(yellow2);
        d.fillCircle(130, 130, 48);
        java.awt.Color yellow1 = new java.awt.Color(255, 255, 0);
        d.setColor(yellow1);
        d.fillCircle(130, 130, 40);
    }
    /**
     * notify the sprite that time has passed.
     */
    public void timePassed() {
    }
}
