import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/**
 * A FinalFour class.
 *
 * @author Shurgil and barisya
 */
public class FinalFour implements LevelInformation {
    private BackgroundLevel4 background = new BackgroundLevel4();
    @Override
    public int numberOfBalls() {
        return 3;
    }

    @Override
    public List<Ball> locationOfBalls() {
        List<Ball> balls = new ArrayList<Ball>();
        Ball b1 = new Ball(400, 400, 5, java.awt.Color.WHITE);
        balls.add(b1);
        Ball b2 = new Ball(330, 430, 5, java.awt.Color.WHITE);
        balls.add(b2);
        Ball b3 = new Ball(470, 430, 5, java.awt.Color.WHITE);
        balls.add(b3);
        return balls;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> newList = new ArrayList<Velocity>();
        Velocity velocity1 = new Velocity(2, -4);
        newList.add(velocity1);
        Velocity velocity2 = new Velocity(3, -4);
        newList.add(velocity2);
        Velocity velocity3 = new Velocity(5, -4);
        newList.add(velocity3);
        return newList;
    }

    @Override
    public int paddleSpeed() {
        return 30;
    }

    @Override
    public int paddleWidth() {
        // return 600;
        return 80;
    }

    @Override
    public Point paddleLocation() {
        return new Point(360.0, 570.0);
    }

    @Override
    public String levelName() {
        String str = "Green 3";
        return str;
    }

    @Override
    public Sprite getBackground() {
        return this.background;
    }

    @Override
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<Block>();

        int width = 52;
        int height = 20;
        int starty = 10 + (5 * height);
        for (int y = starty; y < starty + (height * 7); y = y + (height)) {

            Random rand = new Random();
            float r = rand.nextFloat();
            float g = rand.nextFloat();
            float b = rand.nextFloat();
            java.awt.Color randomColor = new java.awt.Color(r, g, b);

            // java.awt.Color color = java.awt.Color.RED;

            for (int x = 790; x >= 10; x = x - (width)) {

                Point p = new Point(x, y);
                Block block = new Block(p, width, height, randomColor);
                blockList.add(block);

            }
        }

        return blockList;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return 40;
    }
}
