import java.util.ArrayList;
import java.util.List;
/**
 * A WideEasy class.
 *
 * @author Shurgil and barisya
 */
public class WideEasy implements LevelInformation {
    private BackgroundLevel2 background = new BackgroundLevel2();
    @Override
    public int numberOfBalls() {
        return 10;
    }

    @Override
    public List<Ball> locationOfBalls() {
        List<Ball> balls = new ArrayList<Ball>();
        Ball b1 = new Ball(370, 200, 5, java.awt.Color.WHITE);
        balls.add(b1);
        Ball b2 = new Ball(430, 200, 5, java.awt.Color.WHITE);
        balls.add(b2);
        Ball b3 = new Ball(340, 205, 5, java.awt.Color.WHITE);
        balls.add(b3);
        Ball b4 = new Ball(470, 205, 5, java.awt.Color.WHITE);
        balls.add(b4);
        Ball b5 = new Ball(310, 215, 5, java.awt.Color.WHITE);
        balls.add(b5);
        Ball b6 = new Ball(500, 215, 5, java.awt.Color.WHITE);
        balls.add(b6);
        Ball b7 = new Ball(280, 230, 5, java.awt.Color.WHITE);
        balls.add(b7);
        Ball b8 = new Ball(530, 230, 5, java.awt.Color.WHITE);
        balls.add(b8);
        Ball b9 = new Ball(250, 255, 5, java.awt.Color.WHITE);
        balls.add(b9);
        Ball b10 = new Ball(560, 255, 5, java.awt.Color.WHITE);
        balls.add(b10);
        return balls;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        List<Velocity> newList = new ArrayList<Velocity>();
        Velocity velocity1 = new Velocity(0.01, -4);
        newList.add(velocity1);
        Velocity velocity2 = new Velocity(0.02, -4);
        newList.add(velocity2);
        Velocity velocity3 = new Velocity(0.03, -4);
        newList.add(velocity3);
        Velocity velocity4 = new Velocity(0.04, -4);
        newList.add(velocity4);
        Velocity velocity5 = new Velocity(0.05, -4);
        newList.add(velocity5);
        Velocity velocity6 = new Velocity(0.06, -4);
        newList.add(velocity6);
        Velocity velocity7 = new Velocity(0.07, -4);
        newList.add(velocity7);
        Velocity velocity8 = new Velocity(0.08, -4);
        newList.add(velocity8);
        Velocity velocity9 = new Velocity(0.09, -4);
        newList.add(velocity9);
        Velocity velocity10 = new Velocity(0.1, -4);
        newList.add(velocity10);
        return newList;
    }

    @Override
    public int paddleSpeed() {
        return 15;
    }

    @Override
    public int paddleWidth() {
        return 600;
    }

    @Override
    public Point paddleLocation() {
        return new Point(100.0, 570.0);
    }

    @Override
    public String levelName() {
        String str = "Wide Easy";
        return str;
    }

    @Override
    public Sprite getBackground() {
        return this.background;
    }

    @Override
    public List<Block> blocks() {
        List<Block> blockList = new ArrayList<Block>();
        Point p1 = new Point(10, 150);
        Block block1 = new Block(p1, 52.0, 20.0, java.awt.Color.RED);
        blockList.add(block1);

        Point p2 = new Point(62, 150);
        Block block2 = new Block(p2, 52.0, 20.0, java.awt.Color.RED);
        blockList.add(block2);
        Point p3 = new Point(114, 150);
        Block block3 = new Block(p3, 52.0, 20.0, java.awt.Color.ORANGE);
        blockList.add(block3);
        Point p4 = new Point(166, 150);
        Block block4 = new Block(p4, 52.0, 20.0, java.awt.Color.ORANGE);
        blockList.add(block4);
        Point p5 = new Point(218, 150);
        Block block5 = new Block(p5, 52.0, 20.0, java.awt.Color.YELLOW);
        blockList.add(block5);
        Point p6 = new Point(270, 150);
        Block block6 = new Block(p6, 52.0, 20.0, java.awt.Color.YELLOW);
        blockList.add(block6);
        Point p7 = new Point(322, 150);
        java.awt.Color lightGreen = new java.awt.Color(0, 255, 0);
        Block block7 = new Block(p7, 52.0, 20.0, lightGreen);
        blockList.add(block7);
        Point p8 = new Point(374, 150);
        Block block8 = new Block(p8, 52.0, 20.0, lightGreen);
        blockList.add(block8);
        Point p9 = new Point(426, 150);
        Block block9 = new Block(p9, 52.0, 20.0, java.awt.Color.GREEN);
        blockList.add(block9);
        Point p10 = new Point(478, 150);
        Block block10 = new Block(p10, 52.0, 20.0, java.awt.Color.BLUE);
        blockList.add(block10);
        Point p11 = new Point(530, 150);
        Block block11 = new Block(p11, 52.0, 20.0, java.awt.Color.BLUE);
        blockList.add(block11);
        Point p12 = new Point(582, 150);
        Block block12 = new Block(p12, 52.0, 20.0, java.awt.Color.PINK);
        blockList.add(block12);
        Point p13 = new Point(634, 150);
        Block block13 = new Block(p13, 52.0, 20.0, java.awt.Color.PINK);
        blockList.add(block13);

        Point p14 = new Point(686, 150);
        java.awt.Color lightBlue = new java.awt.Color(0, 255, 255);
        Block block14 = new Block(p14, 52.0, 20.0, lightBlue);
        blockList.add(block14);
        Point p15 = new Point(738, 150);
        Block block15 = new Block(p15, 52.0, 20.0, lightBlue);
        blockList.add(block15);

        return blockList;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return 15;
    }
}
