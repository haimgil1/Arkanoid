import biuoop.DrawSurface;

/**
 * A BackgroundLevel4 class.
 *
 * @author Shurgil and barisya
 */
public class BackgroundLevel4 implements Sprite {
    /**
     * draw the sprite to the screen.
     * @param d - the draw surface.
     */
    public void drawOn(DrawSurface d) {

        java.awt.Color lightBlue = new java.awt.Color(0, 255, 255);
        d.setColor(lightBlue);
        d.fillRectangle(0, 40, 800, 560);
        java.awt.Color gray1 = new java.awt.Color(233, 232, 222);
        d.setColor(gray1);
        d.fillCircle(68, 380, 20);
        d.fillCircle(650, 430, 20);
        java.awt.Color gray2 = new java.awt.Color(213, 212, 203);
        d.setColor(gray2);
        d.fillCircle(90, 400, 22);
        d.fillCircle(140, 380, 30);
        d.fillCircle(675, 450, 22);
        d.fillCircle(725, 430, 30);
        java.awt.Color gray3 = new java.awt.Color(210, 207, 184);
        d.setColor(gray3);
        d.fillCircle(100, 370, 25);
        d.fillCircle(680, 415, 25);
        java.awt.Color gray4 = new java.awt.Color(192, 190, 175);
        d.setColor(gray4);
        d.fillCircle(118, 400, 18);
        d.fillCircle(708, 440, 19);
    }
    /**
     * notify the sprite that time has passed.
     */
    public void timePassed() {
    }
}
