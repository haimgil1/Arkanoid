import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
/**
 * A PauseScreen class.
 *
 * @author Shurgil and barisya
 */
public class PauseScreen implements Animation {
    private KeyboardSensor keyboard;
    private boolean stop;

    /**
     * the constructor.
     * @param k the keyboard.
     */
    public PauseScreen(KeyboardSensor k) {
        this.keyboard = k;
        this.stop = false;
    }

    /**
     * do one fremw.
     * @param d the darw surface.
     */
    public void doOneFrame(DrawSurface d) {
        d.drawText(160, d.getHeight() / 2, "paused -- press space to continue",
                32);
        if (this.keyboard.isPressed(KeyboardSensor.SPACE_KEY)) {
            this.stop = true;
        }
    }

    /**
     * @return booleab if should stop.
     */
    public boolean shouldStop() {
        return this.stop;
    }
}
