import biuoop.DrawSurface;

/**
 * A BackgroundLevel3 class.
 *
 * @author Shurgil and barisya
 */
public class BackgroundLevel3 implements Sprite {
    /**
     * draw the sprite to the screen.
     * @param d - the draw surface.
     */
    public void drawOn(DrawSurface d) {

        java.awt.Color green = new java.awt.Color(0, 100, 0);
        d.setColor(green);
        d.fillRectangle(0, 40, 800, 560);

        d.setColor(java.awt.Color.white);
        d.fillRectangle(50, 450, 100, 150);
        java.awt.Color gray = new java.awt.Color(38, 37, 29);
        d.setColor(gray);
        d.fillRectangle(85, 400, 28, 50);
        d.fillRectangle(95, 250, 8, 150);
        d.fillRectangle(50, 450, 100, 7);
        d.fillRectangle(50, 450, 7, 200);
        d.fillRectangle(68, 450, 7, 200);
        d.fillRectangle(86, 450, 7, 200);
        d.fillRectangle(104, 450, 7, 200);
        d.fillRectangle(122, 450, 7, 200);
        d.fillRectangle(140, 450, 10, 200);
        d.fillRectangle(50, 488, 100, 7);
        d.fillRectangle(50, 521, 100, 7);
        d.fillRectangle(50, 554, 100, 7);
        d.fillRectangle(50, 587, 100, 7);

        java.awt.Color yellow = new java.awt.Color(226, 200, 30);
        d.setColor(yellow);
        d.fillCircle(100, 240, 12);
        d.setColor(java.awt.Color.red);
        d.fillCircle(100, 240, 7);
        d.setColor(java.awt.Color.white);
        d.fillCircle(100, 240, 3);
    }
    /**
     * notify the sprite that time has passed.
     */
    public void timePassed() {
    }
}
