import biuoop.DrawSurface;
/**
 * A BackgroundLevel1 class.
 *
 * @author Shurgil and barisya
 */
public class BackgroundLevel1 implements Sprite {
    /**
     * draw the sprite to the screen.
     * @param d
     *            - the draw surface.
     */
    public void drawOn(DrawSurface d) {

        d.setColor(java.awt.Color.black);
        d.fillRectangle(0, 40, 800, 560);

        d.setColor(java.awt.Color.BLUE);
        d.drawCircle(400, 165, 40);
        d.drawCircle(400, 165, 70);
        d.drawCircle(400, 165, 100);
        d.drawLine(400, 290, 400, 50);
        d.drawLine(275, 165, 520, 165);
    }

    /**
     * notify the sprite that time has passed.
     */
    public void timePassed() {

    }
}
