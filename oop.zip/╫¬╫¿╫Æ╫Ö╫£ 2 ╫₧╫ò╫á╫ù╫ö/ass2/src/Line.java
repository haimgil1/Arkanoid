package project1;

/**
 * A Line class.
 *
 * @author Shurgil and barisya
 */
public class Line {
    private Point p1;
    private Point p2;
       /**
       * constructs a line given two points
       *
       * @param start the start of the line
       * @param p2 the end of the line
       */
	   public Line(Point start, Point p2) {
		   this.p1 = start;
		   this.p2 = p2;
	   }
       /**
       * constructs a line given two pairs of x and y coordinates.
       * 
       * @param x1 the x coordinate of the first point
       * @param y1 the y coordinate of the first point
       * @param x2 the x coordinate of the second point
       * @param y2 the y coordinate of the second point
       */
	   public Line(double x1, double y1, double x2, double y2) {
		   this.p1 = new Point(x1, y1);
		   this.p2 = new Point(x2, y2);
	   }

	   /**
	    * @return the length of the line
	    */
	   public double length() {
		   return this.p1.distance(p2); //by the distance between two points
	   }

	   /**
	    * @return the middle point of the line
	    */
	   public Point middle() {
		   double x1 = this.p1.getX();
		   double y1 = this.p1.getY();
		   double x2 = this.p2.getX();
		   double y2 = this.p2.getY();
		   //return the average of the x and y coordinates
		   //of both points of the line
		   Point mid = new Point(((x1 + x2) / 2), ((y1 + y2) / 2));
		   return mid;
	   }

	   /**
	    * @return the start point of the line
	    */
	   public Point start() {
		   return this.p1;
	   }

	   /**
	    * @return the end point of the line
	    */
	   public Point end() {
		   return this.p2;
	   }
	   
	   /**
	    * @param other a line to check if the current line intersects with
	    * @return true if the lines intersect, false otherwise
	    */
	   public boolean isIntersecting(Line other) {
		   boolean check = false;
	        if (this.intersectionWith(other) == null) { //not intersecting
	            return false;
	        }
	        Point intersect = this.intersectionWith(other);
	        if ((((intersect.getX() < this.p1.getX())
	                && (intersect.getX() > this.p2.getX()))
	                || ((intersect.getX() > this.p1.getX())
	                        && (intersect.getX() < this.p2.getX())))
	                        && (((intersect.getX() < other.start().getX())
	                                && (intersect.getX() > other.end().getX()))
	                                || ((intersect.getX() > other.start().getX())
	                                && (intersect.getX() < other.end().getX())))) {
	              check = true;
	              }
	        return check;
	   }

	   /**
	    * @param other a line to find the point of the intersection
	    * @return the intersection point if the lines intersect,
	    * and null otherwise.
	    */
	   public Point intersectionWith(Line other) {
		   double a1 = this.p2.getY() - this.p1.getY();
		   double b1 = this.p1.getX() - this.p2.getX();
		   double c1 = a1 * this.p1.getX() + b1 * this.p1.getY();	   
		   double a2 = other.end().getY() - other.start().getY();
		   double b2 = other.start().getX() - other.end().getX();
		   double c2 = a2 * other.start().getX() + b2 * other.start().getY();
		   double det = (a1 * b2) - (a2 * b1);
		   if (det == 0) {
			   return null;
		   } else {
			   double x = (b2 * c1 - b1 * c2) / det;
			   double y = (a1 * c2 - a2 * c1) / det;
			   Point intersection = new Point(x, y);
			   return intersection;
		   }
	   }

	   /**
	    * @param other a line to check if the current line equals to it
	    * @return true if the lines are equal, false otherwise
	    */
	   public boolean equals(Line other) {
		   //checks if both x and y coordinates equal each other
		   if (this.p1.getX() == other.start().getX() &&
				   this.p1.getY() == other.start().getY()) {
			   return true;
		   } else {
			   return false;
		   }
	   }	    
	}
