package project1;

import biuoop.DrawSurface;

/**
 * A Ball class.
 *
 * @author Shurgil and barisya
 */
public class Ball {
	private Point center;
    private int radius;
    private java.awt.Color color;
    private double dx;
    private double dy;
    private int borderX;
    private int borderY;
    
       /**
       * construct a ball given the center, the radius and the color
       * 
       * @param center the center of the ball (its location)
       * @param r the radius of the circle
       * @param color the color of the ball
       */
	   public Ball(Point center, int r, java.awt.Color color) {
		   this.center = center;
	       this.radius = r;
	       this.color = color;
	   }

       /**
       * construct a ball given the x and y coordinates of the center point,
       * the radius and the color
       * 
       * @param x the x coordinate of the center point
       * @param y the y coordinate of the center point
       * @param r the radius of the circle
       * @param color the color of the ball
       */
	   public Ball(int x, int y, int r, java.awt.Color color) {
		   this.center = new Point(x ,y);
	       this.radius = r;
	       this.color = color;
	   }

       /**
       * construct a ball given the x and y coordinates of the center point,
       * the radius, the color and the width and height of the border
       * 
       * @param x the x coordinate of the center point
       * @param y the y coordinate of the center point
       * @param r the radius of the circle
       * @param color the color of the ball
       * @param bx the width of the border
       * @param by the height of the border
       */ 
	   public Ball(int x, int y, int r, java.awt.Color color, int bx, int by) {
		   this.center = new Point(x ,y);
	       this.radius = r;
	       this.color = color;
	       this.borderX = bx;
	       this.borderY = by;
	   }

	   /**
	    * @return the x coordinate of the ball (the center)
	    */
	   public int getX() {
		   return (int) center.getX();
	   }
	   
	   /**
	    * @return the y coordinate of the ball (the center)
	    */
	   public int getY() {
		   return (int) center.getY();
	   }
	   
	   /**
	    * @return the size of the ball (the radius)
	    */
	   public int getSize() {
		   return this.radius;
	   }
	   
	   /**
	    * @return the color of the ball
	    */
	   public java.awt.Color getColor() {
		   return this.color;
	   }

	   /**
	    * @param surface the given DrawSurface to draw the ball on
	    */
	   public void drawOn(DrawSurface surface) {
		   //get the x and y coordinates of the center of the ball
		   int x = (int) this.center.getX();
		   int y = (int) this.center.getY();
		   surface.setColor(this.color);
		   //and fill in the circle
		   surface.fillCircle(x, y, this.radius);
	   }

       /**
       * construct the dx and dy coordinates of the ball's velocity,
       * given the velocity
       * 
       * @param velocity the given velocity of the ball
       */
	   public void setVelocity(Velocity v) {
		   this.dx = v.getDx();
		   this.dy = v.getDy();
	   }

       /**
       * construct the dx and dy coordinates of the ball's velocity,
       * given the x and y coordinates of the velocity
       * 
       * @param dx the dx coordinate of the velocity
       * @param dy the dy coordinate of the velocity
       */
	   public void setVelocity(double dx, double dy) {
		   this.dx = dx;
		   this.dy = dy;
	   }

	   /**
	    * @return the ball's velocity
	    */
	   public Velocity getVelocity() {
		   double dx = this.dx;
		   double dy = this.dy;
		   //creating a new velocity according to the
		   //dx and dy coordinates of the ball
		   Velocity ballVelocity = new Velocity(dx, dy);
		   return ballVelocity;
	   }

	   /**
	    * this method moves the ball but makes
	    * sure it does not go out of the screen
	    */
	   public void moveOneStep() {
		   //getting the x and y coordinates of the center
		   double ballX = this.center.getX();
		   double ballY = this.center.getY();
		   
		   //checks the ball's x coordinates to make sure it doesn't
		   //go out of the border of the screen
		   if (ballX + this.dx + this.radius >= this.borderX ||
				   ballX + this.dx - this.radius <= 0) {
			   //and if so, sets the velocity in the opposite direction
			   setVelocity(-(this.dx), dy);
		   }

		   //checks the ball's y coordinates to make sure it doesn't
		   //go out of the border of the screen
		   if (ballY + this.dy + this.radius >= this.borderY ||
				   ballY + this.dy - this.radius <= 0) {
			   //and if so, sets the velocity in the opposite direction
			   setVelocity(dx, -(this.dy));
		   }
		   //and sets the new velocity on the ball's center 
	       this.center = this.getVelocity().applyToPoint(this.center);
	   }
	}
