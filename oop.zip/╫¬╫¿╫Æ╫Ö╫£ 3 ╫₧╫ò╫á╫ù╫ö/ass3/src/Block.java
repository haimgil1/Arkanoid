import biuoop.DrawSurface;
/**
 * A Block class.
 *
 * @author Shurgil and barisya
 */
public class Block implements Collidable, Sprite {
    private Point upperLeft;
    private double width;
    private double height;
    private int hitPoints;
    private java.awt.Color color;
    /**
     * Create a new rectangle with location and width/height.
     * @param w - width of the block.
     * @param h - height of the block.
     * @param c - color of the block.
     * @param upPoint - up left point of the block.
     */
    public Block(Point upPoint, double w, double h, java.awt.Color c) {
        this.upperLeft = upPoint;
        this.width = w;
        this.height = h;
        this.color = c;
    }
    /**
     *Create a hit points.
     *@param num the number to set in the hit.
     */
    public void setHitPoints(int num) {
        this.hitPoints = num;
    }
    /**
     * @return the hit points.
     */
    public int getHitPoints() {
        return this.hitPoints;
    }
    /**
     * @return the block by new rectangle.
     */
    public Rectangle getCollisionRectangle() {
        Rectangle rect = new Rectangle(this.upperLeft,
                this.width, this.height);
        return rect;
    }
    /**
     * @param currentVelocity - the current velocity.
     * @param collisionPoint - the collision point.
     * draw the block on it.
     * @return the new velocity.
     */
    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {
        Velocity newVelocity;
        double dx = currentVelocity.getDx();
        double dy = currentVelocity.getDy();

        Line up = this.getCollisionRectangle().getUpperLine();
        Line down = this.getCollisionRectangle().getLowerLine();
        Line right = this.getCollisionRectangle().getRightLine();
        Line left = this.getCollisionRectangle().getLeftLine();

        if (up.isPointOnLine(collisionPoint)
                || down.isPointOnLine(collisionPoint)) {
            newVelocity = new Velocity(dx, -dy);
            this.hitPoints--;
            return newVelocity;
        } else {
            if (left.isPointOnLine(collisionPoint)
                    || right.isPointOnLine(collisionPoint)) {
                newVelocity = new Velocity(-dx, dy);
                this.hitPoints--;
                return newVelocity;
            }
            return currentVelocity;
        }
    }
    /**
     * @param surface - a draw on surface.
     * draw the block on it.
     */
    public void drawOn(DrawSurface surface) {
        // get the x and y coordinates of the center of the ball
        surface.setColor(this.color);
        // and fill in the circle
        surface.fillRectangle((int) this.upperLeft.getX(),
                (int) this.upperLeft.getY(), (int) this.width,
                (int) this.height);
        surface.setColor(java.awt.Color.black);
        surface.drawRectangle((int) this.upperLeft.getX(),
                (int) this.upperLeft.getY(), (int) this.width,
                (int) this.height);
        int x = (int) (this.upperLeft.getX() + this.width / 2);
        int y = (int) (this.upperLeft.getY() + this.height / 2);

        String st2;
        if (this.hitPoints < 1) {
            st2 = "X";
        } else {
            st2 = String.valueOf(this.hitPoints);
        }
        int c = 15;
        surface.setColor(java.awt.Color.WHITE);
        surface.drawText(x, y, st2, c);
    }
    /**
     * a sprite interface method.
     */
    public void timePassed() {

    }
    /**
     * @param g - a game.
     * add this block to the game, to the sprite list
     * and to the colldiable list of the game.
     */
    public void addToGame(Game g) {
        g.addSprite(this);
        g.addCollidable(this);
    }

}
