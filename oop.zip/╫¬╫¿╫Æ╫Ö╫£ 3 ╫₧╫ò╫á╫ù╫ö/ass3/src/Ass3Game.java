/**
 * A Ass3Game class. - main.
 *
 * @author Shurgil and barisya
 */
public class Ass3Game {
    /**
     * the main project.
     * @param args from command line.
     */
    public static void main(String[] args) {
           Game game = new Game();
           game.initialize();
           game.run();
        }
}
