import java.util.ArrayList;
import java.util.List;
import biuoop.DrawSurface;
/**
 * class spritecollection.
 */
public class SpriteCollection {

    private List spriteList;
    /**
     * get a new list.
     */
    public SpriteCollection() {
        this.spriteList = new ArrayList();
    }
    /**
     * @param s - a sprite.
     * add to the sprite list.
     */
    public void addSprite(Sprite s) {
        this.spriteList.add(s);
    }
    /**
     * call timePassed() on all sprites.
     */
    public void notifyAllTimePassed() {
        for (int i = 0; i < this.spriteList.size(); i++) {
            Sprite s = (Sprite) this.spriteList.get(i);
            s.timePassed();
        }
    }
    /**
     * @param d - the draw surface.
     * call drawOn(d) on all sprites.
     */
    public void drawAllOn(DrawSurface d) {
        for (int i = 0; i < spriteList.size(); i++) {
            Sprite s = (Sprite) spriteList.get(i);
            s.drawOn(d);
        }
    }
}
