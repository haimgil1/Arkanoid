import java.util.Random;

import biuoop.DrawSurface;
import biuoop.GUI;
/**
 * A game class.
 *
 * @author Shurgil and barisya
 */
public class Game {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;
    /**
     * @param c - a collidable.
     *add a collidable to the list of game environment.
     */
    public void addCollidable(Collidable c) {
        if (this.environment == null) {
            this.environment = new GameEnvironment();
        }
        this.environment.addCollidable(c);
    }
    /**
     * @param s a sprite object.
     *add a sprite to the list of sprites.
     */
    public void addSprite(Sprite s) {
        if (this.sprites == null) {
            this.sprites = new SpriteCollection();
        }
        this.sprites.addSprite(s);
    }
    /**
     * Initialize a new game: create the Blocks and Ball (and Paddle)
     * and add them to the game.
     */
    public void initialize() {

        this.gui = new GUI("title", 700, 400);
        Ball ball = new Ball(40, 50, 5, java.awt.Color.BLACK, 700, 400);
        ball.setVelocity(2, 4);
        ball.addToGame(this);

        Ball ball2 = new Ball(40, 150, 5, java.awt.Color.BLACK, 700, 400);
        ball2.setVelocity(2, 4);
        ball2.addToGame(this);

        int var = 0;
        int width = 45;
        int height = 20;
        int starty = 10 + (3 * height);
        for (int y = starty; y < starty + (height * 6);) {

            int x = 690 - width;

            Random rand = new Random();
            float r = rand.nextFloat();
            float g = rand.nextFloat();
            float b = rand.nextFloat();
            java.awt.Color randomColor = new java.awt.Color(r, g, b);

            for (; x > 149 + var;) {

                Point p = new Point(x, y);
                Block block = new Block(p, width, height, randomColor);
                block.addToGame(this);

                if (y == starty) {
                    block.setHitPoints(2);
                } else {
                    block.setHitPoints(1);
                }
                x = x - (width);
            }
            y = y + (height);
            var = var + (width);
        }

        // borders
        Point p1 = new Point(0, 0);
        Block blockUp = new Block(p1, 700.0, 10.0, java.awt.Color.GRAY);
        blockUp.addToGame(this);
        blockUp.setHitPoints(-1);

        Point p2 = new Point(690, 0);
        Block blockRight = new Block(p2, 10.0, 400.0, java.awt.Color.GRAY);
        blockRight.addToGame(this);
        blockRight.setHitPoints(-1);

        Point p3 = new Point(0, 0);
        Block blockLeft = new Block(p3, 10.0, 400.0, java.awt.Color.GRAY);
        blockLeft.addToGame(this);
        blockLeft.setHitPoints(-1);

        Point p4 = new Point(0, 390);
        Block blockDown = new Block(p4, 700.0, 10.0, java.awt.Color.GRAY);
        blockDown.addToGame(this);
        blockDown.setHitPoints(-1);

        Point p11 = new Point(50, 370);
        Paddle paddle = new Paddle(p11, 80.0, 20.0, gui.getKeyboardSensor(),
                this.gui);
        paddle.addToGame(this);

        ball.ballSetEnvironment(environment);
        ball.setPaddle(paddle);

        ball2.ballSetEnvironment(environment);
        ball2.setPaddle(paddle);

    }
    /**
     * Run the game -- start the animation loop.
     */
    public void run() {
        biuoop.Sleeper sleeper = new biuoop.Sleeper();
        // ...
        int framesPerSecond = 60;
        int millisecondsPerFrame = 1000 / framesPerSecond;
        while (true) {
            long startTime = System.currentTimeMillis(); // timing

            DrawSurface d = this.gui.getDrawSurface();
            this.sprites.drawAllOn(d);
            gui.show(d);
            this.sprites.notifyAllTimePassed();

            // timing
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }
}
